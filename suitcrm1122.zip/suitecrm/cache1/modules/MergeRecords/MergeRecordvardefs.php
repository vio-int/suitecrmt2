<?php 
 $GLOBALS["dictionary"]["MergeRecord"]=array (
  'table' => 'does_not_exist',
  'fields' => 
  array (
  ),
);