<?php /* Smarty version 2.6.29, created on 2018-07-18 10:08:09
         compiled from include/SugarEmailAddress/templates/optInStatusTick.tpl */ ?>
<span class="email-opt-in-container"><span class="email-opt-in <?php echo $this->_tpl_vars['optInFlagClass']; ?>
" title="<?php echo $this->_tpl_vars['optInFlagTitle']; ?>
"><?php echo $this->_tpl_vars['optInFlagText']; ?>
</span></span>